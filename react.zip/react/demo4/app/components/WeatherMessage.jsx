var React = require('react');

var WeatherMessage = React.createClass({
  render: function () {
    return (
      <h3>It's it 30 in Pune(India).</h3>
    )
  }
});

module.exports = WeatherMessage;
