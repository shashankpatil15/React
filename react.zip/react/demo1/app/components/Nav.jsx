var React = require('react');

var Nav = React.createClass({
  render: function () {
    return (
      <h2>Nav Component</h2>
    );
  }
});

module.exports = Nav;
