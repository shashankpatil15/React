var React = require('react');

var Weather = React.createClass({
  render: function () {
    return (
      <h3>Weather Component</h3>
    )
  }
});

module.exports = Weather;
